from setuptools import setup

setup(name="packageharry",
      version="0.1",
     description="This is code with harry package",
     long_description="",
     author="Harry",
     packages=['packageharry'],
     install_requires=[])